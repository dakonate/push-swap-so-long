/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bubble_sort.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jdemers <jdemers@student.42quebec.>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/11 16:31:21 by jdemers           #+#    #+#             */
/*   Updated: 2024/03/27 18:47:10 by jdemers          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	bubble_sort(t_list *stack, int size)
{
	int		val[3];
	t_list	*stack_b;

	stack_b = NULL;
	val[2] = 0;
	while (!is_sorted(stack, size - val[2]))
	{
		val[0] = get_val(stack);
		val[1] = get_val(stack->next);
		if (val[0] == val[2] && ft_loopsize(stack_b) < size - 3)
		{
			val[2]++;
			push(&stack, &stack_b, 'b');
		}
		else if (val[0] < val[1])
			rev_rotate(&stack, 'a');
		else
			swap(&stack, 'a');
	}
	while (stack_b != NULL)
		push(&stack_b, &stack, 'a');
}
