/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jdemers <jdemers@student.42quebec.>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/06 15:15:20 by jdemers           #+#    #+#             */
/*   Updated: 2024/03/27 18:46:50 by jdemers          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static int	is_valid_int(char *num)
{
	int		i;
	char	limit[11];

	i = 0;
	ft_strlcpy(limit, "2147483647", 11);
	if (*num == '-')
		limit[9] = '8';
	if (*num == '+' || *num == '-')
		num++;
	while (*num == '0')
		num++;
	while (ft_isdigit(num[i]))
		i++;
	if (num[i] != '\0' || i > 10)
		return (0);
	if (i < 10)
		return (1);
	i = -1;
	while (++i < 10)
	{
		if (num[i] == limit[i])
			continue ;
		return (num[i] < limit[i]);
	}
	return (1);
}

static int	*to_int(char **str_stack, int size)
{
	int	*int_stack;
	int	i;
	int	j;

	int_stack = malloc(size * sizeof(int));
	if (int_stack == NULL)
		ft_error();
	i = -1;
	while (++i < size)
	{
		int_stack[i] = ft_atoi(str_stack[i]);
		j = i;
		while (--j >= 0)
		{
			if (int_stack[i] == int_stack[j])
				ft_error();
		}
	}
	return (int_stack);
}

static int	get_normalized_val(int *int_stack, int size, int val)
{
	int	norm;
	int	i;

	norm = 0;
	i = 0;
	while (i < size)
	{
		if (val > int_stack[i++])
			norm++;
	}
	return (norm);
}

static t_list	*init_stack(int *int_stack, int size)
{
	t_list	*stack;
	t_list	*item;
	int		*data;
	int		i;

	i = -1;
	stack = NULL;
	while (++i < size)
	{
		data = malloc(sizeof(int));
		if (data == NULL)
			ft_error();
		*data = get_normalized_val(int_stack, size, int_stack[i]);
		item = ft_loopnew(data);
		if (item == NULL)
			ft_error();
		ft_loopadd_back(&stack, item);
	}
	free(int_stack);
	return (stack);
}

int	main(int ac, char **av)
{
	int		i;
	t_list	*stack;

	if (ac-- < 2)
		return (0);
	i = 0;
	av++;
	while (i < ac && is_valid_int(av[i]))
		i++;
	if (i < ac)
		ft_error();
	stack = init_stack(to_int(av, ac), ac);
	if (ac >= 25)
		radix_sort(stack, largest_bit(ac - 1));
	else
		bubble_sort(stack, ac);
	ft_loopclear(&stack, &free);
	return (0);
}
