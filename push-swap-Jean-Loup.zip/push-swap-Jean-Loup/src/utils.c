/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jdemers <jdemers@student.42quebec.>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/07 11:16:31 by jdemers           #+#    #+#             */
/*   Updated: 2024/03/28 11:57:37 by jdemers          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_error(void)
{
	ft_putendl_fd("\e[1;31mError\e[0m", 2);
	exit(EXIT_FAILURE);
}

int	get_val(t_list *item)
{
	return (*(int *)item->data);
}

t_bool	is_sorted(t_list *stack, int size)
{
	int	i;

	i = 0;
	while (++i < size)
	{
		if (get_val(stack) > get_val(stack->next))
			return (false);
		stack = stack->next;
	}
	return (true);
}

int	*get_tab(t_list *stack)
{
	int	*tab;
	int	size;
	int	i;

	size = ft_loopsize(stack);
	tab = malloc(size * sizeof(int));
	if (tab == NULL)
		ft_error();
	i = -1;
	while (++i < size)
	{
		tab[i] = get_val(stack);
		stack = stack->next;
	}
	return (tab);
}

int	largest_bit(int num)
{
	int	bit;
	int	pow;

	bit = 0;
	pow = 2;
	while (num > pow - 1)
	{
		bit++;
		pow *= 2;
	}
	return (bit);
}
