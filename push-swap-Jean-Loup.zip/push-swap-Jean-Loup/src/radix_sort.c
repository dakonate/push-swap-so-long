/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   radix_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jdemers <jdemers@student.42quebec.>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/14 15:14:57 by jdemers           #+#    #+#             */
/*   Updated: 2024/03/27 15:15:41 by jdemers          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static int	scan_bit(t_list *stack, int bit)
{
	int		to_rotate;
	t_list	*end;

	if ((get_val(stack) >> bit) % 2 == 1)
		to_rotate = 1;
	else
		to_rotate = 0;
	end = stack;
	stack = stack->next;
	while (stack != end)
	{
		if ((get_val(stack) >> bit) % 2 == 1)
			to_rotate++;
		stack = stack->next;
	}
	return (to_rotate);
}

void	radix_sort(t_list *stack_a, int last_bit)
{
	static int	bit = 0;
	t_list		*stack_b;
	int			i;

	stack_b = NULL;
	if (bit > last_bit)
		return ;
	i = scan_bit(stack_a, bit);
	while (i > 0)
	{
		if ((get_val(stack_a) >> bit) % 2 == 0)
			push(&stack_a, &stack_b, 'b');
		else
		{
			i--;
			rotate(&stack_a, 'a');
		}
	}
	while (stack_b != NULL)
		push(&stack_b, &stack_a, 'a');
	bit++;
	radix_sort(stack_a, last_bit);
}
