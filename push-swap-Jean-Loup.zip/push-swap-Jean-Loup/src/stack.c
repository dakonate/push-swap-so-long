/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jdemers <jdemers@student.42quebec.>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/05 14:41:05 by jdemers           #+#    #+#             */
/*   Updated: 2024/03/28 11:42:51 by jdemers          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	swap(t_list **stack, char target)
{
	t_list	*tmp;

	if (*stack == NULL || (*stack)->next == *stack)
		return ;
	tmp = (*stack)->next;
	(*stack)->next = tmp->next;
	(*stack)->next->prev = *stack;
	ft_loopadd_front(stack, tmp);
	ft_printf("s%c\n", target);
}

void	push(t_list **src, t_list **dst, char target)
{
	t_list	*tmp;

	if (*src == NULL)
		return ;
	tmp = *src;
	if (tmp->next == tmp)
		*src = NULL;
	else
	{
		*src = tmp->next;
		(*src)->prev = tmp->prev;
		(*src)->prev->next = *src;
	}
	if (*dst == NULL)
	{
		tmp->next = tmp;
		tmp->prev = tmp;
	}
	ft_loopadd_front(dst, tmp);
	ft_printf("p%c\n", target);
}

void	rotate(t_list **stack, char target)
{
	if (*stack == NULL || (*stack)->next == *stack)
		return ;
	*stack = (*stack)->next;
	ft_printf("r%c\n", target);
}

void	rev_rotate(t_list **stack, char target)
{
	if (*stack == NULL || (*stack)->next == *stack)
		return ;
	*stack = (*stack)->prev;
	ft_printf("rr%c\n", target);
}
