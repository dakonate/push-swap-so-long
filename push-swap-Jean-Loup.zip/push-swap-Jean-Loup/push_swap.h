/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jdemers <jdemers@student.42quebec.>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/11 16:24:42 by jdemers           #+#    #+#             */
/*   Updated: 2024/03/28 11:43:42 by jdemers          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H
# include "libft.h"

void	swap(t_list **stack, char target);
void	push(t_list **src, t_list **dst, char target);
void	rotate(t_list **stack, char target);
void	rev_rotate(t_list **stack, char target);

void	ft_error(void);
t_bool	is_sorted(t_list *stack, int size);
int		get_val(t_list *item);
int		get_tab(t_list *stack);
void	add_output(const char *move, char target);
int		largest_bit(int num);

void	bubble_sort(t_list *stack, int size);
void	radix_sort(t_list *stack_a, int last_bit);

#endif
